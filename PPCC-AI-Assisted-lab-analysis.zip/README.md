# Lab: Agentic Power Platform Development
Build a Power Platform app with AI agents, the TALXIS SDK and TALXIS components: a monorepo, ephemeral Dev/Test
environments, trunk-based development, PR quality gates and GitHub Actions deployments.

## Start here

> **Workshop attendees:** open [LAB-GUIDE.md](LAB-GUIDE.md) (right-click → **Open Preview**) and follow it with Copilot Chat. This README is the reference for running the scripts yourself.

1. **Fork** this repo to your personal GitHub account (top-right **Fork** button).
2. First set your Codespaces **Default idle timeout** to 240 minutes at [github.com/settings/codespaces](https://github.com/settings/codespaces) (the default, 30 minutes, stops the Codespace during any longer pause; the setting only applies to Codespaces created afterwards). Then, on **your fork** (`https://github.com/<you>/lab`), click **Code → Codespaces → Create codespace on main**.
   All tools are preinstalled. The Codespace and free GitHub Actions minutes run on *your* account.

   > ⚠️ Don't use a "one-click" badge that points at `TALXIS/lab` — that starts the Codespace on the parent repo, where you can't push and your free minutes won't apply. Always launch from your own fork.

3. Wait for VS Code to load in the browser. Open a terminal (Ctrl+`) — you're in PowerShell.
   The tools update for about a minute after the Codespace opens; wait until the terminal goes quiet.
4. Work through the **Checkpoints** below, starting with `CP01`. CP01 is the only one you
   truly must run first — it's the step that signs you in. After that, every checkpoint
   checks its own prerequisites (both `.lab-state.json` and this machine's live CLI
   sessions) before doing anything, so re-running a checkpoint that already succeeded is
   safe, and you can jump ahead or skip one you don't need. If a checkpoint can't find
   something it needs, it tells you exactly which earlier checkpoint to (re-)run. Not sure
   where you left off? Run `.lab-scripts/lab-status.ps1` for a summary.

> 💡 Each checkpoint script is fully commented — open it, read what it does, then run the whole file.

### Signing in (CP01)

`CP01` signs you in to everything up front: **GitHub** (`gh`), **Power Platform** (`txc`),
**Azure** (`az`) and **Power Apps** (`pa`). On your own computer a browser window opens; in
Codespaces you get a **code** instead — open the printed link, enter the code, and approve.
When prompted, allow the `workflow` scope for `gh` so later checkpoints can install GitHub
Actions on your fork. Use the same account for Power Platform, Azure and Power Apps.

To sign in again later (new Codespace, expired sign-in), run `.lab-scripts/lab-signin.ps1`, or
ask Copilot Chat to *sign me in* and it walks you through each step.

## How each checkpoint works (PR flow)

Checkpoints don't push straight to `main` — they teach the real ALM loop. Each one:

1. Creates a `checkpoint/cpNN` branch and commits its changes.
2. Opens a **Pull Request** and prints the link.
3. **Pauses** — open the PR in your browser, review the diff and the running build check.
4. Press **Enter** to continue: it squash-merges, deletes the branch, and moves the `cpNN` tag
   to the merged commit for rollback. You can also click **Merge pull request** on GitHub first;
   pressing Enter afterwards just finishes the save. (Run without a terminal, for example by an
   agent, the script says "Review and merge the PR on GitHub" and carries on once you merge.) Once CP13 makes the build check required, the merge
   waits for it to pass — before that, GitHub accepts the merge right away, which is the point
   CP13 makes.

This is the slow, deliberate part — read the PR, watch the build go green, then merge. The
first time a checkpoint enables GitHub Actions you may be asked to **approve workflows on your
fork** — say yes.

Re-running a checkpoint is safe: with nothing new to commit it only makes sure the tag is
there; with new changes it opens another PR for the same checkpoint and moves the tag; and a
PR left open by an interrupted run is picked up again instead of duplicated.

## Checkpoints

| # | Script | Goal |
|---|--------|------|
| 01 | `CP01-check-machine-setup.ps1` | Verify all tools are installed |
| 02 | `CP02-create-repository-layout.ps1` | Monorepo layout (solution, src, NuGet) |
| 03 | `CP03-setup-continuous-integration.ps1` | Branch protection — gated PRs into main |
| 04 | `CP04-setup-runtime.ps1` | Create Dev + Test Dataverse environments |
| 05 | `CP05-setup-continuous-deployment.ps1` | OIDC service principal + deploy workflow (identifiers live in `deploy.yml`, no secrets) |
| 06 | `CP06-implement-data-model.ps1` | Warehouse tables and columns |
| 07 | `CP07-implement-backend.ps1` | Plugins + logic solution |
| 08 | `CP08-implement-security.ps1` | Security roles |
| 09 | `CP09-implement-ui.ps1` | Model-driven app, sitemap, forms, views, grid PCF, warehouse picking code app (TALXIS base controls, Forms, phone-friendly Home quick actions) |
| 10 | `CP10-deploy-and-sync.ps1` | Deploy to Dev & pull changes back |
| 11 | `CP11-integrate-external-data.ps1` | External data integration: Product table, custom connector, code app wiring, barcode scan UI |
| 12 | `CP12-move-configuration.ps1` | Configuration data migration (CMT) |
| 13 | `CP13-extend-branch-policies-build-checks.ps1` | Require build check on PRs |
| 14 | `CP14-automate-ui-testing.ps1` | BDD UI test project + (manual) test workflow |
| 15 | `CP15-implement-unit-tests.ps1` | Plugin (FakeXrmEasy) + script (Jest) unit tests |

Run a checkpoint:

```powershell
.lab-scripts/CP01-check-machine-setup.ps1
```

## Checkpoint tags

Every checkpoint commits, pushes, and tags its result; the tag marks the latest run of that
checkpoint. Use the tags to look at how the repo looked at any point (`git checkout tags/cp05`,
then `git switch main` to come back). They are not a rewind button: `main` on your fork keeps
its history, because the branch protection from CP03 refuses force pushes to it, exactly as
it would on a real team. To undo a checkpoint for real, open a PR that reverts its commit, or
start over on a fresh fork. Re-running a checkpoint is the normal way to fix one that failed
partway.

Your variables persist in `.lab-state.json` (committed), so you can resume on a fresh
Codespace even if your terminal crashes.

## Resuming on a different machine

`.lab-state.json` travels with the repo, but auth sessions and CLI profiles (gh/txc/az)
live on whatever machine you're on right now — they don't come along with a `git clone`.
To pick up the lab on a fresh Codespace, VM, or after a crash:

1. Clone the repo (or open a new Codespace on your fork). The checkpoint tags come with it.
2. Run `.lab-scripts/lab-status.ps1` — it reports which checkpoints are done according to
   `.lab-state.json` and git tags, and whether this machine's own `gh`/`txc`/`az` sessions
   actually match what lab-state expects (a mismatch here is the most common reason a
   checkpoint fails partway through instead of at the top with a clear message).
3. Run `.lab-scripts/lab-signin.ps1` if `lab-status.ps1` flags missing/mismatched auth, then continue with
   whichever checkpoint it names as next. Each checkpoint starts by bringing `main` up to date
   with your fork, so a checkpoint whose PR you merged on GitHub from another machine is
   picked up as done.

## Developing this lab

See [LOCAL-DRY-RUN.md](LOCAL-DRY-RUN.md) to run the checkpoints locally, without forking to
GitHub or provisioning real infrastructure.
