#
# ╔════════════════════════════════════════════════════════════════════════════════════════╗
# ║          08: Logic Solution — Plugin Assembly and SDK Message Processing Steps         ║
# ╚════════════════════════════════════════════════════════════════════════════════════════╝
#
# Creates Solutions.Logic, references Plugins.Warehouse (the build registers the assembly)
# and adds the SDK message processing steps.
# Expects: $PublisherName, $PublisherPrefix from parent scope.
# Expects: Plugins.Warehouse already built (07-plugins.ps1).
#
# ──────────────────────────────────────────────────────────────────────────────────────────
#                                  Solutions.Logic
# ──────────────────────────────────────────────────────────────────────────────────────────

Write-Host "`n── Solutions.Logic ──" -ForegroundColor Cyan

if (-not (Get-LabValue 'logicSolutionScaffolded')) {

txc workspace component create pp-solution `
    --output "src/Solutions.Logic" `
    --param "PublisherName=$PublisherName" `
    --param "PublisherPrefix=$PublisherPrefix"

Write-Host "  ✓ Solutions.Logic" -ForegroundColor Green

# Add Solutions.Logic to the Package Deployer project
cd src/Packages.Main
dotnet add "./Packages.Main.csproj" reference "../Solutions.Logic/Solutions.Logic.csproj"
cd ../..

Write-Host "  ✓ ProjectReference: Logic → Packages.Main" -ForegroundColor Green

# Link plugin project to the logic solution
cd src/Solutions.Logic
dotnet add reference ../Plugins.Warehouse/Plugins.Warehouse.csproj
cd ../..

Write-Host "  ✓ ProjectReference: Plugins.Warehouse → Solutions.Logic" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                              Build Logic Solution
# ──────────────────────────────────────────────────────────────────────────────────────────

# No pp-plugin-assembly call: pp-solution defaults to GeneratePluginAssembly=true, so this
# first build registers the referenced plugin assembly in the solution itself. Scaffolding
# the assembly by hand as well is only for GeneratePluginAssembly=false; after a generated
# build it adds a second PluginAssembly root and the next build fails (#83).
Write-Host "  → Building Solutions.Logic..." -ForegroundColor White
cd src/Solutions.Logic
dotnet build --nologo --verbosity quiet
if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ Logic build succeeded" -ForegroundColor Green
} else {
    Write-Host "  ⚠ Logic build had issues (exit code: $LASTEXITCODE)" -ForegroundColor Yellow
}
cd ../..

# ──────────────────────────────────────────────────────────────────────────────────────────
#                      SDK Message Processing Steps
# ──────────────────────────────────────────────────────────────────────────────────────────

# PreValidation step — ValidateWarehouseTransactionPlugin
# Runs before the DB transaction starts: the cheapest place to reject invalid input.
txc workspace component create pp-plugin-assembly-step `
    --output "src/Solutions.Logic" `
    --param "PrimaryEntity=${PublisherPrefix}_warehousetransaction" `
    --param "PluginProjectName=Plugins.Warehouse" `
    --param "PluginName=ValidateWarehouseTransactionPlugin" `
    --param "Stage=Pre-validation" `
    --param "SdkMessage=Create"


Write-Host "  ✓ Step: ValidateWarehouseTransactionPlugin (Pre-validation, Create)" -ForegroundColor Green

# PostOperation step — SubtractQuantityPlugin
# Runs after the record is written, still inside the transaction: the stock update and
# the transaction record commit or roll back together.
txc workspace component create pp-plugin-assembly-step `
    --output "src/Solutions.Logic" `
    --param "PrimaryEntity=${PublisherPrefix}_warehousetransaction" `
    --param "PluginProjectName=Plugins.Warehouse" `
    --param "PluginName=SubtractQuantityPlugin" `
    --param "Stage=Post-operation" `
    --param "SdkMessage=Create"


Write-Host "  ✓ Step: SubtractQuantityPlugin (Post-operation, Create)" -ForegroundColor Green

# Marks the whole block done — checked instead of Test-Path on the solution csproj so a
# re-run after a partial failure (e.g. solution created but step registration didn't
# finish) retries everything rather than silently skipping the missing work.
Set-LabValue 'logicSolutionScaffolded' $true

} else {
    Write-Host "  ✓ Solutions.Logic (exists)" -ForegroundColor Green
}