#
# ╔════════════════════════════════════════════════════════════════════════════════════════╗
# ║              11: Tests.UI — Playwright / Reqnroll UI Test Project                      ║
# ╚════════════════════════════════════════════════════════════════════════════════════════╝
#
# Creates a Playwright-based BDD test project using the pp-test-ui template.
# Includes frozen step bindings for model-driven app surfaces (forms, views,
# command bar, navigation) and a sample feature file, plus a second feature +
# hand-authored custom steps for the Warehouse Picking code app — a standalone SPA the
# frozen bindings can't navigate to, since those only know the model-driven app's URL shape.
#
# Expects: $PublisherPrefix from parent scope.
#
# ──────────────────────────────────────────────────────────────────────────────────────────

Write-Host "`n── Tests.UI ──" -ForegroundColor Cyan

# ──────────────────────────────────────────────────────────────────────────────────────────
#                              Scaffold Test Project
# ──────────────────────────────────────────────────────────────────────────────────────────

if (-not (Get-LabValue 'testsUiScaffolded')) {

txc workspace component create pp-test-ui `
    --output "src/Tests.UI"

# Add to solution
dotnet sln add src/Tests.UI/Tests.UI.csproj

Write-Host "  ✓ Tests.UI project created" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                              Sample Feature File
# ──────────────────────────────────────────────────────────────────────────────────────────

txc workspace component create pp-test-ui-feature `
    --param "name=WarehouseItemNavigation" `
    --output "src/Tests.UI"

# Remove Calculator sample that ships with both templates
Remove-Item "src/Tests.UI/Features/Calculator.feature" -ErrorAction SilentlyContinue
Remove-Item "src/Tests.UI/Features/Calculator.feature.cs" -ErrorAction SilentlyContinue

Write-Host "  ✓ Sample feature: WarehouseItemNavigation.feature" -ForegroundColor Green

# Write a meaningful scenario into the feature file
# Note: replace the login step value with your actual test user account
$testUser = if ($env:TXC_TEST_USER) { $env:TXC_TEST_USER } else { "your-user@yourtenant.onmicrosoft.com" }
# Full source: .lab-scripts/templates/11-tests-ui/WarehouseItemNavigation.feature
Expand-LabTemplate -Path "11-tests-ui/WarehouseItemNavigation.feature" `
    -Destination "src/Tests.UI/Features/WarehouseItemNavigation.feature" `
    -Tokens @{ TEST_USER = $testUser; PREFIX = $PublisherPrefix }
Write-Host "  ✓ Feature scenario written" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                       Warehouse Picking Feature (code app)
# ──────────────────────────────────────────────────────────────────────────────────────────
#
# The frozen bindings under Support/Bindings/ only cover the model-driven app (they navigate
# via main.aspx?appname=..., a URL the code app — a standalone SPA — doesn't have). This
# scenario needs its own steps, kept in StepDefinitions/ to signal "ours, not
# template-shipped" — same split the pp-test-ui template itself uses for genux/custom pages.

txc workspace component create pp-test-ui-feature `
    --param "name=WarehousePicking" `
    --output "src/Tests.UI"

# pp-test-ui-feature only scaffolds an empty "Feature: WarehousePicking" stub — Reqnroll
# generates the .feature.cs designer file from it at build time, nothing to remove here.
# We overwrite the stub with the real scenarios below via Expand-LabTemplate, same as
# WarehouseItemNavigation above.

# Full source: .lab-scripts/templates/11-tests-ui/WarehousePicking.feature
Expand-LabTemplate -Path "11-tests-ui/WarehousePicking.feature" `
    -Destination "src/Tests.UI/Features/WarehousePicking.feature" `
    -Tokens @{ TEST_USER = $testUser }

New-Item -ItemType Directory -Path "src/Tests.UI/StepDefinitions" -Force | Out-Null
# Full source: .lab-scripts/templates/11-tests-ui/WarehousePickingSteps.cs
Expand-LabTemplate -Path "11-tests-ui/WarehousePickingSteps.cs" `
    -Destination "src/Tests.UI/StepDefinitions/WarehousePickingSteps.cs"

Write-Host "  ✓ Feature scenario written: WarehousePicking.feature + custom steps" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                              Configure appsettings.json
# ──────────────────────────────────────────────────────────────────────────────────────────
#
# All settings can be overridden via environment variables:
#   TXC_ENVIRONMENT_URL, TXC_APP_NAME, TXC_HEADLESS, TXC_SLOWMO,
#   TXC_TIMEOUT, TXC_STORAGE_STATE_PATH, TXC_SCREENSHOT_ON_FAILURE, TXC_TRACING_ENABLED
#
# To capture auth state for headless runs (Codespaces):
#   playwright-cli open --browser=msedge --headed <env-url>    # local machine with display
#   playwright-cli state-save src/Tests.UI/auth-state.json
#   playwright-cli close
#
# NOTE: StorageStatePath must be an absolute path — relative paths resolve from the test
#       binary output directory (bin/Debug/<tfm>/) and are silently ignored by Playwright.
#       Set TXC_STORAGE_STATE_PATH env var at test run time for a portable override.

$envUrl = if ($env:TXC_ENVIRONMENT_URL) { $env:TXC_ENVIRONMENT_URL } else { "https://yourenv.crm.dynamics.com" }
# Resolve to absolute path — works cross-platform (Windows, Linux/Codespaces, macOS)
$authStatePath = [System.IO.Path]::GetFullPath("src/Tests.UI/auth-state.json").Replace('\', '/')
# Full source: .lab-scripts/templates/11-tests-ui/appsettings.json
Expand-LabTemplate -Path "11-tests-ui/appsettings.json" `
    -Destination "src/Tests.UI/appsettings.json" `
    -Tokens @{ ENV_URL = $envUrl; AUTH_STATE_PATH = $authStatePath }
Write-Host "  ✓ appsettings.json configured" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                              Build + Install Playwright
# ──────────────────────────────────────────────────────────────────────────────────────────

Write-Host "  → Building Tests.UI..." -ForegroundColor White
dotnet build src/Tests.UI/Tests.UI.csproj --nologo --verbosity quiet
if ($LASTEXITCODE -eq 0) {
    Write-Host "  ✓ Build succeeded" -ForegroundColor Green
} else {
    Write-Host "  ⚠ Build had issues (exit code: $LASTEXITCODE)" -ForegroundColor Yellow
}

# Detect actual output TFM from build output directory
$debugDir = "src/Tests.UI/bin/Debug"
$tfm = if (Test-Path $debugDir) {
    Get-ChildItem -Path $debugDir -Directory | Select-Object -First 1 -ExpandProperty Name
} else { "net8.0" }

Write-Host "  → Installing Playwright browsers (TFM: $tfm)..." -ForegroundColor White
$playwrightScript = "src/Tests.UI/bin/Debug/$tfm/playwright.ps1"
if (Test-Path $playwrightScript) {
    pwsh $playwrightScript install chromium
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✓ Playwright browsers installed" -ForegroundColor Green
    } else {
        Write-Host "  ⚠ Playwright install had issues (exit code: $LASTEXITCODE)" -ForegroundColor Yellow
    }
} else {
    Write-Host "  ⚠ playwright.ps1 not found at $playwrightScript — run dotnet build first" -ForegroundColor Yellow
}

# Marks the whole block done — checked instead of Test-Path on the csproj so a re-run after
# a partial failure (e.g. project created but the feature file/build didn't finish) retries
# everything rather than silently skipping the missing work.
Set-LabValue 'testsUiScaffolded' $true

} else {
    Write-Host "  ✓ Tests.UI (exists)" -ForegroundColor Green
}

