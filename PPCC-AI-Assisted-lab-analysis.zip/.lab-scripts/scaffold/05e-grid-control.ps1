#
# ╔════════════════════════════════════════════════════════════════════════════════════════╗
# ║             05e: TALXIS Grid — PCF overlay + Script Library customization              ║
# ╚════════════════════════════════════════════════════════════════════════════════════════╝
#
# Overlays the TALXIS Grid PCF control on the "Warehouse Items" subgrid of the
# Warehouse Location form via `txc workspace control attach` — the CLI reads the
# parameter schema from the control's own ControlManifest.xml (no per-control
# template needed) — then customizes the grid at runtime from our own Scripts.UI
# web resource through the control's Client API bridge:
#
#   FormXml:  ClientApiWebresourceName = lab_main.js
#             ClientApiFunctionName    = WarehouseScripts.GridApi.onDatasetControlInitialized
#   The PCF calls that function once its dataset exists; our script registers
#   interceptors (rename a column) and record expressions (paint low-stock cells red).
#
# The Grid control itself ships as a public Package Deployer package on nuget.org
# (TALXIS.Controls.Grid.Package). Nothing is downloaded by hand and no version is
# pinned: `control attach` resolves the latest version of the NuGet package itself,
# and CP10 imports the same package into Dev by name BEFORE the app package, because
# the patched form now references the control.
#
# Expects: $PublisherPrefix from parent scope (after 05a–05d and 09-form-scripts),
#          TALXIS.CLI with `workspace control attach`.

$prefix = $PublisherPrefix
$gridPackage = "TALXIS.Controls.Grid.Package"

# Skipped once it has fully run, so re-running the checkpoint doesn't create everything again.
if (Get-LabValue 'gridControlScaffolded') {
    Write-Host "  ✓ TALXIS Grid on the Warehouse Items subgrid (exist)" -ForegroundColor Green
    return
}

# ──────────────────────────────────────────────────────────────────────────────────────────
#                     Recover generated artifacts (form, view)
# ──────────────────────────────────────────────────────────────────────────────────────────

# Recover the form GUID from the FormXml file name, the same way 05d recovers view GUIDs.
# (05c also records it in lab-state, but the file name holds for any tree, including
# one scaffolded before that.)
$locationFormFile = Get-ChildItem "src/Solutions.UI/Entities/${prefix}_warehouselocation/FormXml/main/*.xml" | Select-Object -First 1
if (-not $locationFormFile) { Write-Host "  ✗ Warehouse Location form not found — run CP09 first" -ForegroundColor Red; throw "Warehouse Location form not found" }
$locationFormGuid = $locationFormFile.BaseName.Trim('{}')

# ──────────────────────────────────────────────────────────────────────────────────────────
#            Add Reorder Point to the item view (data for the low-stock rule)
# ──────────────────────────────────────────────────────────────────────────────────────────

$itemViewFile = Get-ChildItem "src/Solutions.UI/Entities/${prefix}_warehouseitem/SavedQueries/*.xml" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $itemViewFile) { Write-Host "  ✗ Warehouse Item view not found — run CP09 first" -ForegroundColor Red; throw "Warehouse Item view not found" }
$itemViewXml  = [xml](Get-Content $itemViewFile.FullName -Raw)
if (-not $itemViewXml.SelectSingleNode("//cell[@name='${prefix}_reorderpoint']")) {
    $cell = $itemViewXml.CreateElement("cell")
    $cell.SetAttribute("name", "${prefix}_reorderpoint")
    $cell.SetAttribute("width", "125")
    $itemViewXml.SelectSingleNode("//row").AppendChild($cell) | Out-Null

    $attr = $itemViewXml.CreateElement("attribute")
    $attr.SetAttribute("name", "${prefix}_reorderpoint")
    $itemViewXml.SelectSingleNode("//entity").AppendChild($attr) | Out-Null

    $itemViewXml.Save($itemViewFile.FullName)
}
Write-Host "  ✓ Item view includes ${prefix}_reorderpoint" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                    Scripts.UI: Client API bridge + grid customization
# ──────────────────────────────────────────────────────────────────────────────────────────

Write-Host "`n── Scripts.UI: GridApi ──" -ForegroundColor Cyan

# Typings only (import type) — the runtime objects come from the PCF at call time,
# so nothing from these packages ends up in the bundle. The two extra @types are
# peer type-dependencies of @talxis/client-libraries' declarations.
cd src/Scripts.UI
npm pkg set "devDependencies.@talxis/client-libraries=^1.2606.5" `
            "devDependencies.@types/powerapps-component-framework=^1.3.15" `
            "devDependencies.@microsoft/microsoft-graph-types=^2.40.0"
npm install --no-audit --no-fund | Out-Null
if ($LASTEXITCODE -ne 0) { Write-Host "  ⚠ npm install had issues (exit code: $LASTEXITCODE)" -ForegroundColor Yellow }
cd ../..
Write-Host "  ✓ @talxis/client-libraries typings (devDependency)" -ForegroundColor Green

# Full source: .lab-scripts/templates/05e-grid-control/GridCustomizer.ts
Expand-LabTemplate -Path "05e-grid-control/GridCustomizer.ts" `
    -Destination "src/Scripts.UI/src/GridCustomizer.ts" `
    -Tokens @{ PREFIX = $prefix }

$indexPath = "src/Scripts.UI/src/index.ts"
if (-not (Select-String -Path $indexPath -Pattern "GridCustomizer" -Quiet)) {
    Add-Content -Path $indexPath -Value "`nexport { GridApi, LocationForm } from './GridCustomizer';" -Encoding UTF8
}
Write-Host "  ✓ GridCustomizer.ts (GridApi bridge + LocationForm)" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#              Register onLoad handler (also adds lab_main.js to the form)
# ──────────────────────────────────────────────────────────────────────────────────────────

# The template's post-scripts add the Library to <formLibraries> — required, because
# the form must load the web resource before the PCF can call into it.
txc workspace component create pp-form-event-handler `
    --output "src/Solutions.UI" `
    --param "FormType=main" `
    --param "FormId=$locationFormGuid" `
    --param "EntityLogicalName=${prefix}_warehouselocation" `
    --param "LibraryName=${prefix}_main" `
    --param "FunctionName=WarehouseScripts.LocationForm.onLoad" `
    --param "EventType=onload"

Write-Host "  ✓ Event handler: warehouselocation form → onLoad" -ForegroundColor Green

# ──────────────────────────────────────────────────────────────────────────────────────────
#                 Attach TALXIS Grid to the items subgrid (manifest-driven)
# ──────────────────────────────────────────────────────────────────────────────────────────

Write-Host "`n── Grid overlay (txc workspace control attach) ──" -ForegroundColor Cyan

# The attach command copies the subgrid's binding (view + RelationshipName, set by
# pp-form-subgrid in 05d) into the grid — nothing is patched by hand here.
# No per-control template and no manual download: the CLI pulls the package from
# nuget.org, reads the parameter schema straight from its ControlManifest.xml,
# validates the values, and writes the controlDescriptions overlay into the form
# (one customControl block per form factor). Unspecified parameters keep the
# control's manifest defaults.
# Columns: group by category, sum the quantity, keep reorder point available but hidden.
$columnsJson = "[ { `"name`": `"${prefix}_category`", `"grouping`": { `"isGrouped`": true } }, { `"name`": `"${prefix}_availablequantity`", `"aggregation`": { `"aggregationFunction`": `"sum`" } }, { `"name`": `"${prefix}_reorderpoint`", `"isHidden`": true } ]"

txc workspace control attach `
    --output "src/Solutions.UI" `
    --entity "${prefix}_warehouselocation" `
    --form-id $locationFormGuid `
    --target-control "subgrid" `
    --package $gridPackage `
    --param "Columns=$columnsJson" `
    --param "EnableGrouping=true" `
    --param "EnableAggregation=true" `
    --param "EnableOptionSetColors=true" `
    --param "ClientApiWebresourceName=${prefix}_main.js" `
    --param "ClientApiFunctionName=WarehouseScripts.GridApi.onDatasetControlInitialized" `
    --force

if ($LASTEXITCODE -ne 0) { Write-Host "  ✗ txc workspace control attach failed" -ForegroundColor Red; throw "txc workspace control attach failed" }
Write-Host "  ✓ talxis_TALXIS.PCF.Grid attached to the Warehouse Items subgrid" -ForegroundColor Green

# Set last: a re-run after a partial failure retries the whole script.
Set-LabValue 'gridControlScaffolded' $true
