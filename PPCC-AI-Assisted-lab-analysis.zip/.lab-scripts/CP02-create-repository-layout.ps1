#!/usr/bin/env pwsh
#
# ╔════════════════════════════════════════════════════════════════════════════════════════╗
# ║                       CP02: Create repository layout                                   ║
# ╚════════════════════════════════════════════════════════════════════════════════════════╝
#
# A Power Platform project is best managed as a monorepo: plugins, scripts, PCFs, connectors
# and solution components live under one Git repo. MSBuild (dotnet build) orchestrates the
# whole build. Why not one repo per component? Splitting tightly-coupled parts multiplies
# overhead - versioned artifact feeds for every dependency, coordinated PRs across repos,
# reviews without full context, and one CI/CD setup per repo. One repo means one history,
# one build, and PRs that show the whole change; split out only what is genuinely reusable
# across projects. Keep the layout shallow and predictable (src/ + one solution file).
# We create:
#   - a Visual Studio solution file (.slnx) to track all projects
#   - NuGet.config pointing at nuget.org for TALXIS DevKit packages
#   - a src/ folder where solutions and code projects will live
#
# We deliberately keep this empty now — checkpoints CP06–CP09 fill it in component by
# component, exactly like real development.
#
# Run:  .lab-scripts/CP02-create-repository-layout.ps1
# ──────────────────────────────────────────────────────────────────────────────────────────

$ErrorActionPreference = "Stop"
. "$PSScriptRoot/lib/Lab.Common.ps1"

Write-Step "CP02 — Repository layout"

Push-Location $LabRoot
try {
    $solutionName = "WarehouseManagement"
    Set-LabValue 'slnxName'       $solutionName
    Set-LabValue 'publisherName'   $LabDefaultPublisherName
    Set-LabValue 'publisherPrefix' $LabDefaultPublisherPrefix

    # Step 1: NuGet feed (TALXIS DevKit build SDK + templates come from nuget.org)
    Copy-Item "$PSScriptRoot/workflows/NuGet.config" "NuGet.config" -Force
    Write-Ok "NuGet.config"

    # Step 2: Visual Studio solution (modern .slnx) to track all projects in the monorepo.
    # .slnx is the new XML solution format - human-readable and merge-friendly, unlike .sln.
    if (-not (Test-Path "$solutionName.slnx")) {
        dotnet new sln --name $solutionName | Out-Null
        if (Test-Path "$solutionName.sln") {
            dotnet sln "$solutionName.sln" migrate | Out-Null
            Remove-Item "$solutionName.sln" -ErrorAction SilentlyContinue
        }
        Write-Ok "$solutionName.slnx"
    } else {
        Write-Ok "$solutionName.slnx (exists)"
    }

    # Step 3: src/ — home for solution and code projects
    if (-not (Test-Path "src")) { New-Item -ItemType Directory -Path "src" | Out-Null }
    New-Item -ItemType File -Path "src/.gitkeep" -Force | Out-Null
    Write-Ok "src/ directory"
}
finally { Pop-Location }

Save-Checkpoint -Id "cp02" -Message "Create monorepo structure for solution and source assets" -Body @'
Set up the repository so the warehouse app can be developed as a single Power Platform monorepo. This gives the team a consistent place for solutions, plugins, and deployment packages.

## Changes
- add WarehouseManagement.slnx to track solution and code projects
- add NuGet.config for TALXIS DevKit dependencies
- create the src/ workspace used by later scaffolding steps
## Testing
- solution scaffold succeeds and the repo layout is ready for follow-up checkpoints
'@
Write-Host "`nNext: .lab-scripts/CP03-setup-continuous-integration.ps1" -ForegroundColor Cyan
