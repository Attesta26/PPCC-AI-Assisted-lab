#!/usr/bin/env pwsh
#
# ╔════════════════════════════════════════════════════════════════════════════════════════╗
# ║                    CP03: Setup Continuous Integration                                  ║
# ╚════════════════════════════════════════════════════════════════════════════════════════╝
#
# We adopt a trunk-based workflow: everyone integrates into 'main' through short-lived
# branches and pull requests. The alternative - long-lived feature branches - drifts away
# from main and ends in merge hell: the longer a branch lives, the bigger and riskier the
# merge. Short-lived topic branches (a day or two, named like users/<name>/<topic>) keep
# every integration small. To protect the trunk we add a branch ruleset that:
#   - blocks direct pushes to main (changes must come via PR)
#   - requires the PR to be up to date and (later, CP13) pass the build check
#
# We work on YOUR fork, so we detect owner/repo from the git origin remote.
#
# Run:  .lab-scripts/CP03-setup-continuous-integration.ps1
# ──────────────────────────────────────────────────────────────────────────────────────────

$ErrorActionPreference = "Stop"
. "$PSScriptRoot/lib/Lab.Common.ps1"

Write-Step "CP03 — Continuous Integration (branch protection)"

if ($env:LAB_LOCAL_MODE) {
    Write-Info "LAB_LOCAL_MODE: skipped — would resolve the origin repo and create the"
    Write-Info "  'lab-main-protection' ruleset (deletion/non_fast_forward/pull_request rules)"
    Write-Info "  via 'gh api repos/<owner>/<repo>/rulesets'. Stubbing repo/ruleset values so"
    Write-Info "  later checkpoints and lab-status.ps1 see this checkpoint as complete."
    Set-LabValue 'repo'            'local/lab.invalid'
    Set-LabValue 'mainRulesetId'   1   # any non-empty value; nothing calls GitHub with it in local mode
    Set-LabValue 'mainRulesetName' 'lab-main-protection'
} else {

# Step 1: Resolve the fork (owner/repo) from the origin remote (not the upstream parent).
$originUrl = git -C $LabRoot remote get-url origin 2>$null
$repo = if ($originUrl -match 'github\.com[:/](.+?)(?:\.git)?$') { $Matches[1] } else { $null }
if (-not $repo) { Write-Err "Could not resolve origin repo. Run 'gh auth login' and ensure origin is your fork."; exit 1 }
Set-LabValue 'repo' $repo
Write-Ok "Repository: $repo"

# Step 2: Create a ruleset requiring pull requests into main (no direct pushes).
$rulesetName = "lab-main-protection"
$ruleset = @{
    name        = $rulesetName
    target      = "branch"
    enforcement = "active"
    conditions  = @{ ref_name = @{ include = @("~DEFAULT_BRANCH"); exclude = @() } }
    rules       = @(
        @{ type = "deletion" },
        @{ type = "non_fast_forward" },
        @{ type = "pull_request"; parameters = @{
            # 0 approvals because you work solo in this lab; a real team requires >= 1 reviewer
            required_approving_review_count   = 0
            dismiss_stale_reviews_on_push     = $true
            require_code_owner_review         = $false
            require_last_push_approval        = $false
            required_review_thread_resolution = $false
        }}
    )
} | ConvertTo-Json -Depth 10

$tmp = New-TemporaryFile
Set-Content -Path $tmp -Value $ruleset -Encoding UTF8
$rulesetRecord = $null
$existingRuleset = gh api "repos/$repo/rulesets" --jq ".[] | select(.name==`"$rulesetName`")" 2>$null
if ($LASTEXITCODE -eq 0 -and $existingRuleset) {
    $rulesetRecord = $existingRuleset | ConvertFrom-Json
    Write-Ok "Ruleset already exists — main already requires PRs"
} else {
    $createdRuleset = gh api -X POST "repos/$repo/rulesets" --input $tmp 2>&1
    if ($LASTEXITCODE -eq 0) {
        $rulesetRecord = ($createdRuleset -join "`n") | ConvertFrom-Json
        Write-Ok "Ruleset created — main now requires PRs"
    } elseif (($createdRuleset -join "`n") -match 'HTTP 40[34]') {
        # Some sandboxes can't change repository settings - then you create the ruleset yourself.
        Write-Warn2 "GitHub refused to create the ruleset from here: $createdRuleset"
        Write-Warn2 "Create it yourself: https://github.com/$repo/settings/rules/new?target=branch"
        Write-Info "  Name '$rulesetName', Active, target the default branch, restrict deletions, require a pull request, block force pushes."
        $deadline = (Get-Date).AddMinutes(30)
        while ($true) {
            $existingRuleset = gh api "repos/$repo/rulesets" --jq ".[] | select(.name==`"$rulesetName`")" 2>&1
            if ($LASTEXITCODE -ne 0) { Write-Err "Checking for the ruleset failed: $existingRuleset - re-run this checkpoint."; exit 1 }
            if ($existingRuleset) { break }
            if ((Get-Date) -gt $deadline) { Write-Err "Ruleset '$rulesetName' still not found on $repo - create it, then re-run this checkpoint."; exit 1 }
            Start-Sleep 15
        }
        $rulesetRecord = $existingRuleset | ConvertFrom-Json
        Write-Ok "Ruleset found — main now requires PRs"
    } else {
        Write-Err "Ruleset creation failed: $createdRuleset"
        Remove-Item $tmp -ErrorAction SilentlyContinue
        exit 1
    }
}
Remove-Item $tmp -ErrorAction SilentlyContinue
Set-LabValue 'mainRulesetId'   $rulesetRecord.id
Set-LabValue 'mainRulesetName' $rulesetRecord.name

}

Save-Checkpoint -Id "cp03" -Message "Add main branch protection for pull request workflow" -Body @'
Protect the main branch so warehouse app changes land through pull requests instead of direct pushes. This establishes the review loop before the first functional features are added.

## Changes
- create the lab-main-protection GitHub ruleset for main
- require pull requests and up-to-date branches before merge
## Testing
- ruleset creation succeeds and main is configured to accept changes through PRs
'@
Write-Host "`nNext: .lab-scripts/CP04-setup-runtime.ps1" -ForegroundColor Cyan
